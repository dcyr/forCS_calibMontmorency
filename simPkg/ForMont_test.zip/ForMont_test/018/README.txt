simID 018
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.9
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

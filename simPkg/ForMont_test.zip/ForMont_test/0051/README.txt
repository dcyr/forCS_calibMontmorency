simID 0051
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.3
initComm PICE.GLA
replicate 1

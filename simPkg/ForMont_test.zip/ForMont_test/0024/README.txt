simID 0024
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.7
initComm ABIE.BAL
replicate 1

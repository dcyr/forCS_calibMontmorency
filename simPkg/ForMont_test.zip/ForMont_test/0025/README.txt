simID 0025
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.7
initComm ABIE.BAL
replicate 1

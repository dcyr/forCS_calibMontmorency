simID 0017
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.5
initComm ABIE.BAL
replicate 1

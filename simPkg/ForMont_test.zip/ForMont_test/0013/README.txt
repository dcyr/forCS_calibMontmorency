simID 0013
areaName ForMont
landtypes 221
treatment CP
growthShape 0.3
initComm ABIE.BAL
replicate 1

simID 0010
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.3
initComm ABIE.BAL
replicate 1

simID 002
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.8
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

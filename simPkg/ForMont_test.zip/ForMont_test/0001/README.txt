simID 0001
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.1
initComm ABIE.BAL
replicate 1

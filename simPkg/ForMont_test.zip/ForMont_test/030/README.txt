simID 030
areaName ForMont
landtypes 222
treatment CP
growthShape 0.95
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

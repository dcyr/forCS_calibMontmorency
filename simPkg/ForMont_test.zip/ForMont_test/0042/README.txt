simID 0042
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.1
initComm PICE.GLA
replicate 1

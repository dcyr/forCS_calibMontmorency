simID 045
areaName ForMont
landtypes 221
treatment CP
growthShape 0.8
initComm PICE.GLA
replicate 1
noRecruitment FALSE

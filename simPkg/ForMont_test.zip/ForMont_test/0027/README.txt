simID 0027
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.7
initComm ABIE.BAL
replicate 1

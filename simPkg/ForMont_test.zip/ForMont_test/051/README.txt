simID 051
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.85
initComm PICE.GLA
replicate 1
noRecruitment FALSE

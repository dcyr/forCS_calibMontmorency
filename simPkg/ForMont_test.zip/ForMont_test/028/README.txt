simID 028
areaName ForMont
landtypes 220
treatment CP
growthShape 0.95
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

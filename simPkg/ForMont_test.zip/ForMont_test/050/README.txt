simID 050
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.85
initComm PICE.GLA
replicate 1
noRecruitment FALSE

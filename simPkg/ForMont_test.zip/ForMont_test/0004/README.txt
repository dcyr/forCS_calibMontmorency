simID 0004
areaName ForMont
landtypes 220
treatment CP
growthShape 0.1
initComm ABIE.BAL
replicate 1

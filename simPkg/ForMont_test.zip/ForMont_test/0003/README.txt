simID 0003
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.1
initComm ABIE.BAL
replicate 1

simID 010
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.85
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

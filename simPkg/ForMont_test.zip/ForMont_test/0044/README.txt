simID 0044
areaName ForMont
landtypes 220
treatment CP
growthShape 0.1
initComm PICE.GLA
replicate 1

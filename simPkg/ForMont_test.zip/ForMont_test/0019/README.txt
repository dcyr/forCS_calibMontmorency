simID 0019
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.5
initComm ABIE.BAL
replicate 1

simID 0012
areaName ForMont
landtypes 220
treatment CP
growthShape 0.3
initComm ABIE.BAL
replicate 1

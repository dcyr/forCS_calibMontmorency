simID 0054
areaName ForMont
landtypes 222
treatment CP
growthShape 0.3
initComm PICE.GLA
replicate 1

simID 047
areaName ForMont
landtypes 223
treatment CP
growthShape 0.8
initComm PICE.GLA
replicate 1
noRecruitment FALSE

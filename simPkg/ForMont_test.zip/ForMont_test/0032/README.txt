simID 0032
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.9
initComm ABIE.BAL
replicate 1

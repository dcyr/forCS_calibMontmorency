simID 008
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.85
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

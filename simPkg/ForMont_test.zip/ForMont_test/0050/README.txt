simID 0050
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.3
initComm PICE.GLA
replicate 1

simID 054
areaName ForMont
landtypes 222
treatment CP
growthShape 0.85
initComm PICE.GLA
replicate 1
noRecruitment FALSE

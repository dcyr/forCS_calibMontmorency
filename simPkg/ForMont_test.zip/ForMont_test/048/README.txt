simID 048
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.85
initComm PICE.GLA
replicate 1
noRecruitment FALSE

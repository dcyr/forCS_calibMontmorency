simID 0053
areaName ForMont
landtypes 221
treatment CP
growthShape 0.3
initComm PICE.GLA
replicate 1

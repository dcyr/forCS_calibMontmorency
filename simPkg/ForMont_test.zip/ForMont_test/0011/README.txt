simID 0011
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.3
initComm ABIE.BAL
replicate 1

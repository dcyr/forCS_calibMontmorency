simID 0015
areaName ForMont
landtypes 223
treatment CP
growthShape 0.3
initComm ABIE.BAL
replicate 1

simID 0041
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.1
initComm PICE.GLA
replicate 1

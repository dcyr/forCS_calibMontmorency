simID 037
areaName ForMont
landtypes 221
treatment CP
growthShape 1
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

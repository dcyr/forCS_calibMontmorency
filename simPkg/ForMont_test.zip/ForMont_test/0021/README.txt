simID 0021
areaName ForMont
landtypes 221
treatment CP
growthShape 0.5
initComm ABIE.BAL
replicate 1

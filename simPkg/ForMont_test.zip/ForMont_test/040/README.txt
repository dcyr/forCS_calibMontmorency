simID 040
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.8
initComm PICE.GLA
replicate 1
noRecruitment FALSE

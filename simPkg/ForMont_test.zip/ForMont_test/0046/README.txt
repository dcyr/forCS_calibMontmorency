simID 0046
areaName ForMont
landtypes 222
treatment CP
growthShape 0.1
initComm PICE.GLA
replicate 1

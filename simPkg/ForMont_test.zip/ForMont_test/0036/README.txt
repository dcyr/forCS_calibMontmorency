simID 0036
areaName ForMont
landtypes 220
treatment CP
growthShape 0.9
initComm ABIE.BAL
replicate 1

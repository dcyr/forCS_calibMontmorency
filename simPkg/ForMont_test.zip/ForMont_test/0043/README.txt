simID 0043
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.1
initComm PICE.GLA
replicate 1

simID 0018
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.5
initComm ABIE.BAL
replicate 1

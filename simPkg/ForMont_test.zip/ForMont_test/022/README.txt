simID 022
areaName ForMont
landtypes 222
treatment CP
growthShape 0.9
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

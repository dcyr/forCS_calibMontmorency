simID 044
areaName ForMont
landtypes 220
treatment CP
growthShape 0.8
initComm PICE.GLA
replicate 1
noRecruitment FALSE

simID 0026
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.7
initComm ABIE.BAL
replicate 1

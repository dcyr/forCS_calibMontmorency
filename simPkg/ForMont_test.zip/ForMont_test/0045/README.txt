simID 0045
areaName ForMont
landtypes 221
treatment CP
growthShape 0.1
initComm PICE.GLA
replicate 1

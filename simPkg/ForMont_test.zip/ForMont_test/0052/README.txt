simID 0052
areaName ForMont
landtypes 220
treatment CP
growthShape 0.3
initComm PICE.GLA
replicate 1

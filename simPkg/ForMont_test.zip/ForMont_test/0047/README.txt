simID 0047
areaName ForMont
landtypes 223
treatment CP
growthShape 0.1
initComm PICE.GLA
replicate 1

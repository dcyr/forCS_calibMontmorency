simID 035
areaName ForMont
landtypes 223
treatment CPRS
growthShape 1
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

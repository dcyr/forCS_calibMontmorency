simID 052
areaName ForMont
landtypes 220
treatment CP
growthShape 0.85
initComm PICE.GLA
replicate 1
noRecruitment FALSE

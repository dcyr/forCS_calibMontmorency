simID 0022
areaName ForMont
landtypes 222
treatment CP
growthShape 0.5
initComm ABIE.BAL
replicate 1

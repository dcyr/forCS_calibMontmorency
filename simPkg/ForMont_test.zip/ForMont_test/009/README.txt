simID 009
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.85
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

simID 025
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.95
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

simID 014
areaName ForMont
landtypes 222
treatment CP
growthShape 0.85
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

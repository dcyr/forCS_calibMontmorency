simID 013
areaName ForMont
landtypes 221
treatment CP
growthShape 0.85
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

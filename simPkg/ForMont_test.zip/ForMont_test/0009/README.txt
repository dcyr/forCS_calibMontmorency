simID 0009
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.3
initComm ABIE.BAL
replicate 1

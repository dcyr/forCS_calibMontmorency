simID 0033
areaName ForMont
landtypes 221
treatment CPRS
growthShape 0.9
initComm ABIE.BAL
replicate 1

simID 0031
areaName ForMont
landtypes 223
treatment CP
growthShape 0.7
initComm ABIE.BAL
replicate 1

simID 0040
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.1
initComm PICE.GLA
replicate 1

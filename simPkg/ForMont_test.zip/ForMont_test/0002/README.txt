simID 0002
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.1
initComm ABIE.BAL
replicate 1

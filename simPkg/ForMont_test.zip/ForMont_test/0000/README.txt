simID 0000
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.1
initComm ABIE.BAL
replicate 1

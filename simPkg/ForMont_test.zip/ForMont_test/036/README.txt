simID 036
areaName ForMont
landtypes 220
treatment CP
growthShape 1
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

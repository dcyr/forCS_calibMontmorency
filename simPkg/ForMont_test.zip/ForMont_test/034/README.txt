simID 034
areaName ForMont
landtypes 222
treatment CPRS
growthShape 1
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

simID 042
areaName ForMont
landtypes 222
treatment CPRS
growthShape 0.8
initComm PICE.GLA
replicate 1
noRecruitment FALSE

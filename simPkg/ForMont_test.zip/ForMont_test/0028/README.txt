simID 0028
areaName ForMont
landtypes 220
treatment CP
growthShape 0.7
initComm ABIE.BAL
replicate 1

simID 0016
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.5
initComm ABIE.BAL
replicate 1

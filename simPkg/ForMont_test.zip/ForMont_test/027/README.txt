simID 027
areaName ForMont
landtypes 223
treatment CPRS
growthShape 0.95
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

simID 038
areaName ForMont
landtypes 222
treatment CP
growthShape 1
initComm ABIE.BAL
replicate 1
noRecruitment FALSE

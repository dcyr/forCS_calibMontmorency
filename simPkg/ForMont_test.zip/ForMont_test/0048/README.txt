simID 0048
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.3
initComm PICE.GLA
replicate 1

simID 0032
areaName ForMont
landtypes 220
treatment CPRS
growthShape 0.8
initComm ABIE.BAL
replicate 1
noRecruitment TRUE

#######################################################################
########### Installed LANDIS-II extensions
#######################################################################
C:\Program Files\LANDIS-II-v7\v7\Landis.Extensions.dll
LANDIS-II 2.0
Extensions Administration Tool 2.0
Copyright 2005-2006 University of Wisconsin
Copyright 2011 Portland State University

Extension    "Age-only Succession"
Version      5.2
Type         succession
Assembly     Landis.Extension.Succession.AgeOnly-v5
Class        Landis.Extension.Succession.AgeOnly.PlugIn
Description  "Succession with age cohorts"

Extension    "Base Fire"
Version      4.0
Type         disturbance:fire
Assembly     Landis.Extension.BaseFire-v4
Class        Landis.Extension.BaseFire.PlugIn
Description  "Fire Disturbance"

Extension    "Base Harvest"
Version      5.1
Type         disturbance:harvest
Assembly     Landis.Extension.BaseHarvest-v5
Class        Landis.Extension.BaseHarvest.PlugIn
Description  "Generic Harvesting for all cohorts"

Extension    "Base Wind"
Version      3.1
Type         disturbance:wind
Assembly     Landis.Extension.BaseWind-v3
Class        Landis.Extension.BaseWind.PlugIn
Description  "Wind Disturbance"

Extension    "Biomass Harvest"
Version      4.4
Type         disturbance:harvest
Assembly     Landis.Extension.BiomassHarvest-v4
Class        Landis.Extension.BiomassHarvest.PlugIn
Description  "Harvesting for biomass cohorts"

Extension    "Biomass Succession"
Version      5.3
Type         succession
Assembly     Landis.Extension.Succession.Biomass-v5
Class        Landis.Extension.Succession.Biomass.PlugIn
Description  "Succession with biomass cohorts"

Extension    "ForC Succession"
Version      3.1
Type         succession
Assembly     Landis.Extension.Succession.ForC-v3.1
Class        Landis.Extension.Succession.ForC.PlugIn
Description  "Forest Carbon Succession with cohorts"

#######################################################################
########### System Info
sysname Windows
release 10 x64
version build 18363
nodename DCYR-Z840
machine x86-64
login dcyr-z840
user dcyr-z840
effective_user dcyr-z840
